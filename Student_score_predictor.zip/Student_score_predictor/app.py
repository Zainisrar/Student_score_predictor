import os
import joblib
from flask import Flask, render_template, request

# Create a Flask web app
app = Flask(__name__,static_url_path='/static')

# Load the linear regression model
model_filename = 'linear_regression_model.pkl'
model = joblib.load(model_filename)

# Define a route for the home page
@app.route('/')
def home():
    return render_template('index.html')

# Define a route for handling predictions
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get the input from the form
        hours = float(request.form['hours'])
        if hours>10:
            prediction=100
            return render_template('index.html', prediction=f'Predicted Score: {round(prediction, 2)}%')
        elif hours<0:
            prediction=0
            return render_template('index.html', prediction=f'Predicted Score: {round(prediction, 2)}%')
        else:
        # Make a prediction using the model
            prediction = model.predict([[hours]])[0]

            return render_template('index.html', prediction=f'Predicted Score: {round(prediction, 2)}%')
    except Exception as e:
        return render_template('index.html', error=f'Error: {str(e)}')

if __name__ == '__main__':
    app.run(debug=True)
